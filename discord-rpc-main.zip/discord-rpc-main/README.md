# discord-rpc
Selamlar! <img src="https://raw.githubusercontent.com/MartinHeinz/MartinHeinz/master/wave.gif" width="30px">

Discord uygulaması arkada açık değilken çalışmaz.

Eğer hata alırsanız bu dosyaları hatanın içindeki klasöre atın. Örn: C:/Users/Administrator


<strong>Çalmayın demicem de altına bir yerine bunun linkini atın paylaşcaksanız</strong>


[<img src = "https://img.shields.io/badge/Reawen GITHUB-%231877F2.svg?&style=for-the-badge&logo=github&logoColor=white">](https://github.com/ReawenJS)
[<img src = "https://img.shields.io/badge/Reawen INSTAGRAM-%FFFFFF.svg?&style=for-the-badge&logo=instagram&logoColor=white">](https://instagram.com/helios_afkk)
